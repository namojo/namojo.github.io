# thunder-kit — Claude Code Game Studios(CCGS) 썬더게임즈 확장 키트

https://namojo.github.io/game-studio/playbook/ 의 단계별 가이드와 함께 쓴다.
CCGS v1.2.0 기준으로 작성·검증했다.

## 들어 있는 것
| 경로 | 용도 | 플레이북 |
|---|---|---|
| `tools/check_gacha.py` | 가챠 데이터 검사기 + 공지용 확률표 생성(`--render`) | 아이디어 1 |
| `.claude/hooks/validate-gacha.sh` | 커밋 직전 자동 검사 훅(실패 시 커밋 차단) | 아이디어 1 |
| `.claude/rules/gacha-data.md` | 가챠 데이터 경로에 자동 적용되는 규칙 | 아이디어 1 |
| `.claude/agents/gacha-compliance.md` | 공시·윤리 정책 검수 에이전트 | 아이디어 1·2 |
| `design/live-ops/ethics-policy.md` | 확률형 상품 "조건부 허용" 윤리 정책 템플릿 | 아이디어 1·2 |
| `design/live-ops/economy-rules.md` | `/team-live-ops`가 읽는 경제 규칙 템플릿 | 아이디어 2 |
| `assets/data/gacha/gacha_sample_pickup.json` | 형식 예시(검사 통과) | 아이디어 1 |
| `snippets/project-yaml-mobile.yaml` | 모바일용 project.yaml 값 | 아이디어 5 |
| `docs/performance/device-tiers.md` | 기기 등급별 성능 예산 템플릿 | 아이디어 5 |
| `tools/install_kit.py` | 훅 등록 + live-ops-designer 원칙 교체 | 설치 |

## 설치 (CCGS 프로젝트 루트에서)
```
# 1) 압축을 풀어 프로젝트 루트에 그대로 복사 (폴더 구조 유지)
# 2) 무엇이 바뀌는지 먼저 본다
python tools/install_kit.py
# 3) 적용
python tools/install_kit.py --apply
# 4) Claude Code 재시작 후 확인
python tools/check_gacha.py assets/data/gacha/gacha_sample_pickup.json
```
Unity 프로젝트라면 가챠 데이터를 `Assets/.../Data/Gacha/gacha_*.json`에 둬도 같은 검사가 걸린다.

## 주의
- 법률 자문이 아니다. 공시 문구·해외 마켓 규정은 법무 검토를 거친다.
- `install_kit.py`는 `live-ops-designer.md`의 두 문장만 바꾼다. 스태미나·P2W 금지 등 나머지
  원칙은 그대로 두었으니, 우리 게임에 맞게 유지할지 팀이 결정한다.
