#!/usr/bin/env python3
"""확률형 아이템(가챠) 데이터 검사기 — thunder-kit

검사 대상: assets/data/gacha/gacha_*.json (Unity: Assets/**/Data/Gacha/gacha_*.json)

사용법
  python tools/check_gacha.py --staged            # git에 스테이징된 가챠 파일만 (커밋 훅이 쓰는 모드)
  python tools/check_gacha.py --staged --worktree # + 아직 add 안 한 수정분까지 (git commit -a 대비)
  python tools/check_gacha.py FILE [FILE ...]     # 지정 파일
  python tools/check_gacha.py --all               # 저장소의 가챠 파일 전부
  python tools/check_gacha.py --render FILE       # 공지용 확률표(마크다운) 출력

종료 코드: 0 통과 / 1 위반 있음 / 2 사용법 오류
표준 라이브러리만 사용한다.
"""
import argparse
import datetime
import fnmatch
import json
import subprocess
import sys
from decimal import Decimal, InvalidOperation

PATTERNS = ["assets/data/gacha/gacha_*.json", "Assets/*Data/Gacha/gacha_*.json", "Assets/**/Data/Gacha/gacha_*.json"]
REQUIRED = ["schema_version", "banner_id", "grades", "disclosure"]
TOTAL = Decimal("100")
MAX_DECIMALS = 4  # 공시 확률은 소수점 넷째 자리까지


def is_gacha_path(path):
    p = path.replace("\\", "/")
    return any(fnmatch.fnmatch(p, pat) for pat in PATTERNS)


def git(*args):
    r = subprocess.run(["git", *args], capture_output=True, text=True, encoding="utf-8")
    return r.returncode, r.stdout


def dec(value, where, errors):
    try:
        d = Decimal(str(value))
    except (InvalidOperation, TypeError):
        errors.append(f"{where}: 확률 값 '{value}'이 숫자가 아닙니다")
        return None
    if d <= 0:
        errors.append(f"{where}: 확률은 0보다 커야 합니다 (현재 {d})")
    if -d.as_tuple().exponent > MAX_DECIMALS:
        errors.append(f"{where}: 소수점 {MAX_DECIMALS}자리를 넘는 확률 {d} — 공시 표기와 실제 값이 어긋날 수 있습니다")
    return d


def rate_signature(data):
    """확률 구성만 뽑아낸 비교용 서명. 공시 문구나 이름이 바뀐 것은 무시한다."""
    sig = []
    for g in data.get("grades", []):
        items = sorted((str(i.get("item_id")), str(i.get("rate"))) for i in g.get("items", []))
        sig.append((str(g.get("grade")), str(g.get("rate")), tuple(items)))
    pity = data.get("pity") or {}
    return (tuple(sorted(sig)), json.dumps(pity, sort_keys=True))


def check(path, data, previous=None):
    errors = []
    for key in REQUIRED:
        if key not in data:
            errors.append(f"필수 키 '{key}'가 없습니다")
    if errors:
        return errors

    grades = data["grades"]
    if not isinstance(grades, list) or not grades:
        return ["'grades'는 비어 있지 않은 배열이어야 합니다"]

    total = Decimal("0")
    names = set()
    item_ids = set()
    for gi, g in enumerate(grades):
        gname = g.get("grade", f"#{gi}")
        if gname in names:
            errors.append(f"등급 '{gname}'이 두 번 정의되었습니다")
        names.add(gname)
        grate = dec(g.get("rate"), f"등급 {gname}", errors)
        if grate is not None:
            total += grate
        items = g.get("items", [])
        if not items:
            errors.append(f"등급 {gname}: 아이템 목록이 비었습니다")
            continue
        isum = Decimal("0")
        for it in items:
            iid = it.get("item_id")
            if not iid:
                errors.append(f"등급 {gname}: item_id 없는 항목이 있습니다")
            elif iid in item_ids:
                errors.append(f"아이템 '{iid}'이 여러 번 등장합니다 — 공시 확률이 합산되지 않습니다")
            item_ids.add(iid)
            irate = dec(it.get("rate"), f"{gname}/{iid}", errors)
            if irate is not None:
                isum += irate
        if grate is not None and isum != grate:
            errors.append(f"등급 {gname}: 아이템 확률 합 {isum}% ≠ 등급 확률 {grate}%")

    if total != TOTAL:
        errors.append(f"전체 등급 확률 합이 {total}% 입니다 (100%여야 함)")

    pity = data.get("pity") or {}
    if pity.get("enabled"):
        if pity.get("guaranteed_grade") not in names:
            errors.append(f"천장 보장 등급 '{pity.get('guaranteed_grade')}'이 grades에 없습니다")
        if not isinstance(pity.get("pulls"), int) or pity["pulls"] <= 0:
            errors.append("천장 'pulls'는 양의 정수여야 합니다")

    disc = data.get("disclosure") or {}
    for key in ("updated_at", "text_ko"):
        if not disc.get(key):
            errors.append(f"disclosure.{key}가 비었습니다 — 공시 정보 없이 배포할 수 없습니다")
    if disc.get("updated_at"):
        try:
            datetime.date.fromisoformat(disc["updated_at"])
        except ValueError:
            errors.append(f"disclosure.updated_at '{disc['updated_at']}'이 YYYY-MM-DD 형식이 아닙니다")

    if previous is not None and rate_signature(previous) != rate_signature(data):
        old = (previous.get("disclosure") or {}).get("updated_at")
        if old and old == disc.get("updated_at"):
            errors.append(
                f"확률 구성이 바뀌었는데 disclosure.updated_at({old})이 그대로입니다 — 공시 갱신일을 고치고 공지를 준비하세요"
            )
    return errors


def load(path, text=None):
    if text is None:
        with open(path, encoding="utf-8") as f:
            text = f.read()
    return json.loads(text)


def previous_version(path):
    code, out = git("show", f"HEAD:{path}")
    if code != 0:
        return None  # 새 파일
    try:
        return json.loads(out)
    except json.JSONDecodeError:
        return None


def staged_text(path):
    code, out = git("show", f":{path}")
    return out if code == 0 else None


def render(data):
    lines = [f"### {data.get('display_name', data['banner_id'])} 확률 정보",
             "", f"공시 갱신일: {data['disclosure'].get('updated_at', '-')}", "",
             "| 등급 | 아이템 | 확률 |", "|---|---|---:|"]
    for g in data["grades"]:
        lines.append(f"| **{g['grade']}** | (등급 합계) | **{g['rate']}%** |")
        for it in g["items"]:
            mark = " (픽업)" if it.get("pickup") else ""
            lines.append(f"| {g['grade']} | {it.get('name_ko', it['item_id'])}{mark} | {it['rate']}% |")
    pity = data.get("pity") or {}
    if pity.get("enabled"):
        lines += ["", f"- {pity['pulls']}회 안에 {pity['guaranteed_grade']} 등급을 획득하지 못하면 {pity['pulls']}회째에 확정 지급됩니다."]
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(description="가챠 데이터 검사기")
    ap.add_argument("files", nargs="*")
    ap.add_argument("--staged", action="store_true")
    ap.add_argument("--worktree", action="store_true")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--render", action="store_true")
    a = ap.parse_args()

    if a.render:
        if len(a.files) != 1:
            print("--render는 파일 하나만 받습니다", file=sys.stderr)
            return 2
        print(render(load(a.files[0])))
        return 0

    targets = []  # (path, text_or_None, compare_with_head)
    if a.staged:
        _, out = git("diff", "--cached", "--name-only", "--diff-filter=ACMR")
        targets = [(p, staged_text(p), True) for p in out.splitlines() if is_gacha_path(p)]
        if a.worktree:
            _, out = git("diff", "--name-only", "--diff-filter=AMR")
            targets = [t for t in targets if t[0] not in out.splitlines()]
            targets += [(p, None, True) for p in out.splitlines() if is_gacha_path(p)]
    elif a.all:
        _, out = git("ls-files")
        targets = [(p, None, False) for p in out.splitlines() if is_gacha_path(p)]
    else:
        targets = [(p, None, False) for p in a.files]

    if not targets:
        return 0

    failed = 0
    for path, text, compare in targets:
        try:
            data = load(path, text)
        except (OSError, json.JSONDecodeError) as e:
            print(f"✗ {path}\n  - JSON을 읽을 수 없습니다: {e}", file=sys.stderr)
            failed += 1
            continue
        errs = check(path, data, previous_version(path) if compare else None)
        if errs:
            failed += 1
            print(f"✗ {path}", file=sys.stderr)
            for e in errs:
                print(f"  - {e}", file=sys.stderr)
        else:
            print(f"✓ {path}")
    if failed:
        print(f"\n가챠 데이터 검사 실패: {failed}개 파일. 고친 뒤 다시 커밋하세요.", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
