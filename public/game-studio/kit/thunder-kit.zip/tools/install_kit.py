#!/usr/bin/env python3
"""thunder-kit 설치 도우미 — CCGS 프로젝트 루트에서 실행한다.

  python tools/install_kit.py           # 무엇을 바꿀지 보여 주기만 한다 (기본)
  python tools/install_kit.py --apply   # 실제로 적용한다

하는 일
  1. .claude/settings.json 의 PreToolUse(Bash|PowerShell)에 validate-gacha.sh 훅을 등록
  2. .claude/agents/live-ops-designer.md 의 "유료 랜덤 박스 금지" 원칙을
     design/live-ops/ethics-policy.md 를 따르는 조건부 허용으로 교체
여러 번 실행해도 결과가 같다(이미 적용된 항목은 건너뛴다). 표준 라이브러리만 사용.
"""
import json
import os
import sys

HOOK_CMD = 'bash "$CLAUDE_PROJECT_DIR/.claude/hooks/validate-gacha.sh"'
SETTINGS = ".claude/settings.json"
LIVEOPS = ".claude/agents/live-ops-designer.md"

LIVEOPS_EDITS = [
    (
        "- No loot boxes with real-money purchase and random outcomes (show odds if any randomness exists)",
        "- Probability items (gacha) are allowed only under `design/live-ops/ethics-policy.md`: "
        "published per-item odds that match `assets/data/gacha/` data, a pity ceiling, and a notice "
        "before any rate change. Route every banner through the `gacha-compliance` agent.",
    ),
    (
        "(loot boxes with\nreal-money purchase and random outcomes, pay-to-complete gating,",
        "(probability items that\nbreak `design/live-ops/ethics-policy.md`, pay-to-complete gating,",
    ),
]


def plan_settings():
    if not os.path.exists(SETTINGS):
        return None, f"✗ {SETTINGS} 가 없습니다 — CCGS 프로젝트 루트에서 실행했는지 확인하세요"
    with open(SETTINGS, encoding="utf-8") as f:
        data = json.load(f)
    pre = data.setdefault("hooks", {}).setdefault("PreToolUse", [])
    for group in pre:
        for h in group.get("hooks", []):
            if "validate-gacha.sh" in h.get("command", ""):
                return None, "· settings.json: 훅이 이미 등록되어 있음 (건너뜀)"
    target = next((g for g in pre if g.get("matcher") == "Bash|PowerShell"), None)
    if target is None:
        target = {"matcher": "Bash|PowerShell", "hooks": []}
        pre.append(target)
    target["hooks"].append({"type": "command", "command": HOOK_CMD, "timeout": 20})
    return data, "+ settings.json: PreToolUse(Bash|PowerShell)에 validate-gacha.sh 등록"


def plan_liveops():
    if not os.path.exists(LIVEOPS):
        return None, [f"· {LIVEOPS} 없음 (건너뜀)"]
    with open(LIVEOPS, encoding="utf-8") as f:
        text = f.read()
    msgs = []
    for old, new in LIVEOPS_EDITS:
        if new in text:
            msgs.append("· live-ops-designer: 이미 교체됨 (건너뜀)")
        elif old in text:
            text = text.replace(old, new, 1)
            msgs.append("+ live-ops-designer: '" + old.split("\n")[0][:48] + "…' 교체")
        else:
            msgs.append("! live-ops-designer: 원문을 찾지 못함 — 버전이 다를 수 있으니 직접 고치세요: " + old.split("\n")[0][:60])
    return text, msgs


def main():
    apply = "--apply" in sys.argv
    settings, smsg = plan_settings()
    liveops, lmsgs = plan_liveops()
    print(smsg)
    for m in lmsgs:
        print(m)
    for required in (".claude/hooks/validate-gacha.sh", "tools/check_gacha.py", "design/live-ops/ethics-policy.md"):
        if not os.path.exists(required):
            print(f"! {required} 가 없습니다 — 키트 파일을 프로젝트 루트에 먼저 복사하세요")
    if not apply:
        print("\n(미리보기) 적용하려면: python tools/install_kit.py --apply")
        return 0
    if settings is not None:
        with open(SETTINGS, "w", encoding="utf-8", newline="\n") as f:
            json.dump(settings, f, ensure_ascii=False, indent=2)
            f.write("\n")
    if liveops is not None:
        with open(LIVEOPS, "w", encoding="utf-8", newline="\n") as f:
            f.write(liveops)
    print("\n적용 완료. Claude Code를 다시 시작해야 훅이 로드됩니다.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
