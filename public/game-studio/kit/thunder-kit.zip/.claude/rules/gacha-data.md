---
paths:
  - "assets/data/gacha/**/*.json"
  - "Assets/**/Data/Gacha/**/*.json"
---

# Gacha (Probability Item) Data Rules — thunder-kit

These files are legally disclosed to players. Treat every number as public.

- File name: `gacha_[banner].json` (snake_case), one banner per file.
- Required keys: `schema_version`, `banner_id`, `grades`, `disclosure`.
- Rates are **percent** values. Grade rates must sum to exactly 100.
  Item rates inside a grade must sum to exactly that grade's rate.
  Use at most 4 decimal places — the in-game notice shows the same number.
- An item appears in only one grade, once.
- If `pity.enabled` is true, `pity.guaranteed_grade` must exist in `grades`
  and `pity.pulls` must be a positive integer.
- `disclosure.updated_at` (YYYY-MM-DD) and `disclosure.text_ko` are mandatory.
  **Whenever any rate or the pity rule changes, update `disclosure.updated_at`**
  and draft the player notice in the same change.
- Never edit these numbers to "make a test pass" or to fit a target revenue figure.
  Rate changes are decided by a person and recorded in the commit message.
- After editing, run `python tools/check_gacha.py <file>`; the commit hook
  `validate-gacha.sh` runs the same check and blocks the commit on failure.
- Generate the notice table with `python tools/check_gacha.py --render <file>`
  instead of retyping numbers by hand.
