#!/bin/bash
# thunder-kit — Claude Code PreToolUse 훅 (Bash|PowerShell)
# git commit 직전에 스테이징된 가챠 데이터(assets/data/gacha/gacha_*.json)를 검사한다.
# Exit 0 = 통과, Exit 2 = 커밋 차단 (stderr가 Claude에게 전달됨)

cd "${CLAUDE_PROJECT_DIR:-$(dirname "${BASH_SOURCE[0]}")/../..}" 2>/dev/null || exit 0

INPUT=$(cat)

# git commit이 아니면 즉시 통과 — 이 훅은 모든 Bash 호출마다 실행된다
case "$INPUT" in *'"tool_input"'*[Gg][Ii][Tt]*[Cc][Oo][Mm][Mm][Ii][Tt]*) ;; *) exit 0 ;; esac

if command -v jq >/dev/null 2>&1; then
  COMMAND=$(printf '%s' "$INPUT" | jq -r '.tool_input.command // empty')
else
  # jq가 없으면 "command" 값만 잘라 낸다 — ERE만 써서 macOS(BSD)·Git Bash(GNU) 모두에서 동작
  COMMAND=$(printf '%s' "$INPUT" | LC_ALL=C grep -oE '"command"[[:space:]]*:[[:space:]]*"(\\.|[^"\\])*"' | head -1 | LC_ALL=C sed -E 's/^"command"[[:space:]]*:[[:space:]]*"//; s/"$//')
fi
# 'git commit', 'git -C dir commit', 'git -c k=v commit'은 잡고 'git log --grep commit'은 거른다
# (commit 앞에는 git 전역 옵션만 올 수 있다)
printf '%s' "$COMMAND" | grep -qE '(^|[;&|[:space:]])git([[:space:]]+(-C|-c)[[:space:]]+[^[:space:]]+|[[:space:]]+--?[a-zA-Z][a-zA-Z-]*(=[^[:space:]]+)?)*[[:space:]]+commit([[:space:]]|$)' || exit 0

# Windows(Git Bash)에서는 python3가 없고 python 또는 py만 있는 경우가 많다
PY=""
for c in python3 python py; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3,8) else 1)' >/dev/null 2>&1; then
    PY="$c"; break
  fi
done

# 가챠 파일이 하나도 안 걸려 있으면 Python 없이도 통과
CHANGED=$( { git diff --cached --name-only; git diff --name-only; } 2>/dev/null | grep -E '(^assets/data/gacha/|/Data/Gacha/).*gacha_[^/]*\.json$' )
[ -z "$CHANGED" ] && exit 0

if [ -z "$PY" ]; then
  echo "가챠 데이터가 커밋에 포함됐지만 Python 3.8+을 찾지 못해 검사할 수 없습니다. Python을 설치한 뒤 다시 커밋하세요." >&2
  exit 2
fi

EXTRA=""
# git commit -a / -am / --all 이면 아직 add 안 한 수정분도 커밋되므로 함께 검사
printf '%s' "$COMMAND" | grep -qE 'commit([[:space:]]+[^[:space:]]+)*[[:space:]]+(-[a-zA-Z]*a[a-zA-Z]*|--all)([[:space:]]|$)' && EXTRA="--worktree"

OUT=$("$PY" tools/check_gacha.py --staged $EXTRA 2>&1)
STATUS=$?
if [ $STATUS -ne 0 ]; then
  echo "$OUT" >&2
  echo "" >&2
  echo "[validate-gacha] 확률형 아이템 데이터 검사에 실패해 커밋을 막았습니다. 위 항목을 고치고 다시 커밋하세요." >&2
  exit 2
fi
exit 0
