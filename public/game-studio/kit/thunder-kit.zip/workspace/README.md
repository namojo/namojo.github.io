# 분석 작업장 (playbook 실전편 R-2)

`new-analysis-workspace.ps1` 한 번으로 운영 게임 역문서화용 "읽기 전용 분석 작업장"을 만든다.
이 폴더(`workspace/`)는 게임 레포에 복사하지 않는다. 내려받은 위치에서 바로 실행한다.

```powershell
Unblock-File .\new-analysis-workspace.ps1
powershell -ExecutionPolicy Bypass -File .\new-analysis-workspace.ps1 `
    -Path C:\work\rpg-analysis `
    -ClientRepo https://git.example.com/rpg/client.git `
    -ServerRepo https://git.example.com/rpg/server.git
```

| 옵션 | 뜻 |
|---|---|
| `-Path` | 새로 만들 작업장 폴더(비어 있어야 함) |
| `-ClientRepo` / `-ServerRepo` | 게임 레포 주소 또는 로컬 경로. 원본 작업 폴더가 아니라 새 사본을 받는다 |
| `-ClientBranch` / `-ServerBranch` | 라이브 빌드 브랜치를 지정할 때 |
| `-ExtraSecretGlobs` | 추가로 읽기를 막을 파일 패턴 (예: `'appsettings.Production.json'`) |
| `-Refresh` | 게임 코드가 바뀐 뒤: 잠금 해제 → pull → 다시 잠금 → 기준 커밋 갱신 |

## 걸리는 잠금 세 겹
1. `CLAUDE.md` 작업장 규칙 — Claude가 스스로 수정을 거절하고, 문장마다 출처 태그를 단다
2. `.claude/settings.local.json` 거부 규칙 — 게임 코드·데이터 수정, 비밀 파일 읽기를 도구 수준에서 거부
3. 파일 읽기 전용 + 사본의 push 주소 차단 + 작업장 git pre-commit 훅(코드·데이터·로그 커밋 금지)

## 하지 말 것
- `src-client/` 등을 작업장 `.gitignore`나 `.git/info/exclude`에 넣지 말 것.
  Claude Code의 Grep 도구는 git 무시 목록을 따르므로 **코드 검색에서 빠진다**(실측 확인).
  커밋 방지는 pre-commit 훅이 맡는다.
- `src-client/` 안에서 `claude`를 실행하지 말 것. 작업장 규칙과 거부 규칙이 로드되지 않는다.
