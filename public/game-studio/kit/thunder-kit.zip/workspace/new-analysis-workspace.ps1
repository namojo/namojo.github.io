﻿<#
.SYNOPSIS
  운영 중인 게임을 역문서화하기 위한 "읽기 전용 분석 작업장"을 만든다. (thunder-kit)

.DESCRIPTION
  1. Claude Code Game Studios(CCGS) 템플릿을 작업장 루트로 받는다
  2. 게임 클라이언트(·서버) 레포를 src-client\, src-server\ 로 새로 받는다 (원본 작업 폴더는 건드리지 않음)
  3. data\ ops\ live\ 폴더와 안내문을 만든다
  4. .claude\settings.local.json 에 수정 금지·비밀 파일 읽기 금지 규칙을 넣는다
  5. CLAUDE.md 끝에 작업장 규칙(출처 태그 포함)을 붙인다
  6. 작업장 git 에 "게임 코드·데이터는 커밋 금지" pre-commit 훅을 건다
  7. 게임 레포 사본의 push 주소를 막고, 파일을 읽기 전용으로 잠근다
  8. 분석 기준 커밋을 workspace-info.md 에 기록한다

  Windows PowerShell 5.1 과 PowerShell 7 에서 동작한다.

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File .\new-analysis-workspace.ps1 `
      -Path C:\work\rpg-analysis -ClientRepo https://git.example.com/rpg/client.git `
      -ServerRepo https://git.example.com/rpg/server.git

.EXAMPLE
  # 게임 코드가 바뀐 뒤 사본을 최신으로 (잠금 해제 → pull → 다시 잠금 → 기준 커밋 갱신)
  powershell -ExecutionPolicy Bypass -File .\new-analysis-workspace.ps1 -Path C:\work\rpg-analysis -Refresh
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Path,
    [string]$ClientRepo,
    [string]$ServerRepo,
    [string]$ClientBranch,
    [string]$ServerBranch,
    [string]$CcgsRepo = 'https://github.com/Donchitos/Claude-Code-Game-Studios.git',
    [string[]]$ExtraSecretGlobs = @(),
    [switch]$Refresh
)

$ErrorActionPreference = 'Stop'
$CodeDirs = @('src-client', 'src-server')
$LockedDirs = @('src-client', 'src-server', 'data', 'ops', 'live')
$Marker = '## Analysis Workspace (thunder-kit)'
$Utf8NoBom = New-Object System.Text.UTF8Encoding $false

function Say([string]$msg, [string]$color = 'Gray') { Write-Host $msg -ForegroundColor $color }
function Step([string]$msg) { Write-Host ''; Write-Host "▶ $msg" -ForegroundColor Cyan }
function Fail([string]$msg) { Write-Host "✗ $msg" -ForegroundColor Red; exit 1 }
function WriteText([string]$file, [string]$text) {
    $dir = Split-Path -Parent $file
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    [System.IO.File]::WriteAllText($file, ($text -replace "`r`n", "`n"), $Utf8NoBom)
}
# 'Git' 이라고 이름 지으면 PowerShell 이 대소문자를 무시해 안쪽 git 호출이 자기 자신을 부른다
function RunGit([string[]]$gitArgs) {
    & git @gitArgs
    if ($LASTEXITCODE -ne 0) { Fail ("git " + ($gitArgs -join ' ') + " 실패 (exit $LASTEXITCODE)") }
}
function SetReadOnly([string]$dir, [bool]$on) {
    if (-not (Test-Path $dir)) { return 0 }
    $n = 0
    Get-ChildItem -LiteralPath $dir -Recurse -File -Force |
        Where-Object { $_.FullName -notmatch '[\\/]\.git([\\/]|$)' } |
        ForEach-Object { if ($_.IsReadOnly -ne $on) { $_.IsReadOnly = $on }; $n++ }
    return $n
}
function HeadOf([string]$repoDir) {
    if (-not (Test-Path (Join-Path $repoDir '.git'))) { return $null }
    $h = (& git -C $repoDir log -1 --format='%H %cs %s') 2>$null
    $b = (& git -C $repoDir rev-parse --abbrev-ref HEAD) 2>$null
    return "$b @ $h"
}
function WriteInfo([string]$root) {
    $lines = @('# 분석 작업장 정보', '',
        '이 작업장의 문서는 아래 커밋을 기준으로 작성되었다. 문서를 읽을 때 기준 시점을 확인할 것.', '',
        '| 대상 | 브랜치 @ 커밋 날짜 메시지 |', '|---|---|')
    foreach ($d in $CodeDirs) {
        $h = HeadOf (Join-Path $root $d)
        if ($h) { $lines += "| $d | $h |" }
    }
    $lines += "| CCGS | $(HeadOf $root) |"
    $lines += ''
    $lines += "기록 시각: $((Get-Date).ToString('yyyy-MM-dd HH:mm'))"
    WriteText (Join-Path $root 'workspace-info.md') (($lines -join "`n") + "`n")
}

# ---------------------------------------------------------------- 사전 점검
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { Fail 'git 이 없습니다. winget install --id Git.Git -e' }
$py = $null
foreach ($c in @('python', 'py', 'python3')) {
    $cmd = Get-Command $c -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source -notmatch 'WindowsApps') { $py = $c; break }
}
if (-not $py) { Say '! Python 3 를 찾지 못했습니다. CCGS 는 Python 없이 설정을 기본값으로만 읽습니다 (winget install --id Python.Python.3.12 -e).' Yellow }

$Path = [System.IO.Path]::GetFullPath($Path)

# ---------------------------------------------------------------- 갱신 모드
if ($Refresh) {
    if (-not (Test-Path (Join-Path $Path 'CLAUDE.md'))) { Fail "$Path 는 분석 작업장이 아닙니다." }
    foreach ($d in $CodeDirs) {
        $dir = Join-Path $Path $d
        if (-not (Test-Path (Join-Path $dir '.git'))) { continue }
        Step "$d 최신으로 갱신"
        $before = HeadOf $dir
        $beforeHash = ((& git -C $dir rev-parse HEAD) + '').Trim()
        [void](SetReadOnly $dir $false)
        RunGit @('-C', $dir, 'pull', '--ff-only')
        $n = SetReadOnly $dir $true
        $after = HeadOf $dir
        Say "  이전: $before"
        Say "  이후: $after"
        Say "  다시 잠금: 파일 $n 개"
        if ($before -ne $after) {
            Say "  바뀐 파일 목록 보기: git -C $d diff --stat $beforeHash HEAD" Yellow
            Add-Content -LiteralPath (Join-Path $Path 'workspace-refresh-log.md') -Value "- $((Get-Date).ToString('yyyy-MM-dd HH:mm')) $d : $beforeHash → $(((& git -C $dir rev-parse HEAD) + '').Trim())" -Encoding UTF8
        } else { Say '  변경 없음' }
    }
    WriteInfo $Path
    Step '완료 — workspace-info.md 의 기준 커밋을 갱신했습니다.'
    Say '  Claude Code 에서: "workspace-refresh-log.md 마지막 줄의 두 커밋 사이에 바뀐 파일을 git diff 로 확인하고, 그 파일을 근거로 쓴 설계 문서 문장을 찾아 다시 확인할 목록을 docs/refresh-review.md 로 정리해 줘"' Green
    exit 0
}

# ---------------------------------------------------------------- 생성 모드
if (-not $ClientRepo) { Fail '-ClientRepo (클라이언트 레포 주소 또는 경로)가 필요합니다.' }
if ((Test-Path $Path) -and (Get-ChildItem -LiteralPath $Path -Force | Select-Object -First 1)) {
    Fail "$Path 가 비어 있지 않습니다. 새 폴더 경로를 지정하세요."
}

Step "1/8 CCGS 템플릿 받기 → $Path"
RunGit @('clone', '--depth', '1', $CcgsRepo, $Path)

Step '2/8 게임 레포 사본 받기 (원본 작업 폴더는 건드리지 않음)'
$clientArgs = @('clone', $ClientRepo, (Join-Path $Path 'src-client'))
if ($ClientBranch) { $clientArgs = @('clone', '--branch', $ClientBranch, $ClientRepo, (Join-Path $Path 'src-client')) }
RunGit $clientArgs
if ($ServerRepo) {
    $serverArgs = @('clone', $ServerRepo, (Join-Path $Path 'src-server'))
    if ($ServerBranch) { $serverArgs = @('clone', '--branch', $ServerBranch, $ServerRepo, (Join-Path $Path 'src-server')) }
    RunGit $serverArgs
}
foreach ($d in $CodeDirs) {
    $dir = Join-Path $Path $d
    if (Test-Path (Join-Path $dir '.git')) {
        # 사본에서 실수로 원본 레포에 push 하지 않도록 push 주소를 막는다 (fetch/pull 은 그대로)
        RunGit @('-C', $dir, 'remote', 'set-url', '--push', 'origin', 'DISABLED-read-only-analysis-copy')
    }
}

Step '3/8 data / ops / live 폴더 만들기'
$readme = @{
    'data' = "밸런스·확률·보상 테이블을 내보내 여기에 둔다 (CSV/JSON).`n파일명에 내보낸 날짜를 붙인다. 예: gacha_rates_2026-10-24.csv`n"
    'ops'  = "운영툴·원격 설정(Remote Config 등)에서 이벤트별로 코드 기본값을 덮어쓰는 값을 내보내 둔다.`n코드에 없는 '실제 라이브 값'은 대부분 여기에 있다.`n"
    'live' = "실제 지급·소환·결제 로그 샘플. 반드시 익명화(유저 ID·IP·결제 식별자 제거)한 뒤 둔다.`n문서와 라이브가 맞는지 대조할 때만 쓴다.`n"
}
foreach ($k in $readme.Keys) { WriteText (Join-Path $Path "$k\README.txt") $readme[$k] }

Step '4/8 Claude 권한 규칙 (.claude\settings.local.json)'
$deny = New-Object System.Collections.Generic.List[string]
foreach ($d in $LockedDirs) { $deny.Add("Edit(/$d/**)") }
$secretGlobs = @('*.pem', '*.key', '*.p12', '*.pfx', '*.keystore', '*.jks', '*secret*', '*Secret*', '*credential*', '*Credential*', '.env*') + $ExtraSecretGlobs
foreach ($d in $CodeDirs) { foreach ($g in $secretGlobs) { $deny.Add("Read(/$d/**/$g)") } }
$localPath = Join-Path $Path '.claude\settings.local.json'
$settings = [ordered]@{ permissions = [ordered]@{ deny = $deny.ToArray() } }
WriteText $localPath (($settings | ConvertTo-Json -Depth 5) + "`n")
Say "  수정 금지 $($LockedDirs.Count)개 폴더, 비밀 파일 읽기 금지 패턴 $($deny.Count - $LockedDirs.Count)개"

Step '5/8 CLAUDE.md 에 작업장 규칙 추가'
$claudeMd = Join-Path $Path 'CLAUDE.md'
$block = @"

$Marker

This is a READ-ONLY analysis workspace for a live mobile game. Never modify anything under
src-client/, src-server/, data/, ops/, live/. Write only to design/, docs/, production/.
Never run git commit, push, reset or checkout inside src-client/ or src-server/.

- src-client/ : game client (Unity project; Assets/ is the code root)
- src-server/ : game server, if present — the server is authoritative for random rolls, rewards and currency
- data/       : exported balance / probability / reward tables
- ops/        : live-ops tool and remote-config overrides (they override code defaults during events)
- live/       : anonymized live logs, only for checking documents against reality
- workspace-info.md : the exact commits these documents describe

Rules for every generated document:
1. Tag each statement with its source: [code] [data] [ops] [owner-confirmed] [inferred].
   Never present [inferred] as fact. Put open questions in a "Questions for owner" section.
2. When code, data and ops disagree, do not pick one — list the disagreement.
3. Cite file paths (and line numbers for code) for every [code] statement.
4. Use git history (git -C src-client log / blame) as evidence of intent, and say so.

Respond to the user in Korean. Keep file names, keys and identifiers in English.

"@
$existing = [System.IO.File]::ReadAllText($claudeMd)
if ($existing -notmatch [regex]::Escape($Marker)) { WriteText $claudeMd ($existing.TrimEnd() + "`n" + $block) }

Step '6/8 작업장 git 에 커밋 방지 훅 설치'
$hook = @'
#!/bin/sh
# thunder-kit: 게임 코드·데이터·로그가 분석 작업장 저장소에 커밋되는 것을 막는다
bad=$(git diff --cached --name-only | grep -E '^(src-client|src-server|data|ops|live)(/|$)' | grep -vE '^(data|ops|live)/README\.txt$')
if [ -n "$bad" ]; then
  echo "[thunder-kit] 게임 코드·데이터·로그는 이 저장소에 커밋할 수 없습니다:" >&2
  echo "$bad" | head -20 >&2
  echo "결과물만 커밋하세요: git add design docs production workspace-info.md" >&2
  exit 1
fi
exit 0
'@
WriteText (Join-Path $Path '.git\hooks\pre-commit') $hook
if ($env:OS -ne 'Windows_NT') { & chmod +x (Join-Path $Path '.git/hooks/pre-commit') }

Step '7/8 게임 코드 사본을 읽기 전용으로 잠그기 (.git 폴더 제외)'
foreach ($d in $CodeDirs) {
    $n = SetReadOnly (Join-Path $Path $d) $true
    if ($n -gt 0) { Say "  $d : 파일 $n 개 잠금" }
}

Step '8/8 분석 기준 커밋 기록 (workspace-info.md)'
WriteInfo $Path
Get-Content (Join-Path $Path 'workspace-info.md') | ForEach-Object { Say "  $_" }

$ver = Join-Path $Path 'src-client\ProjectSettings\ProjectVersion.txt'
$unity = $null
if (Test-Path $ver) {
    $m = Select-String -Path $ver -Pattern 'm_EditorVersion:\s*(\S+)' | Select-Object -First 1
    if ($m) { $unity = $m.Matches[0].Groups[1].Value }
}

Write-Host ''
Write-Host '완료. 다음 순서:' -ForegroundColor Green
Say "  1) cd `"$Path`""
Say '  2) data\ ops\ live\ 의 README.txt 를 보고 내보낸 자료를 넣는다'
Say '  3) claude   (반드시 이 폴더에서 실행 — 하위 폴더에서 띄우면 규칙이 안 걸린다)'
Say '  4) /start  → D(기존 작업)'
if ($unity) { Say "  5) /setup-engine unity $unity" } else { Say '  5) /setup-engine unity <버전>' }
Say '  6) /settings --local modes.review_mode=solo'
