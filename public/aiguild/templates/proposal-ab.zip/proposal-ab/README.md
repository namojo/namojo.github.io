# proposal-ab — 단일 에이전트 vs 하네스

같은 과업지시서 한 건으로 제안서를 두 방식으로 쓴 결과와, 트랙 B를 만든 하네스가 들어 있습니다.
실습 순서는 https://namojo.github.io/aiguild/#s2 를 따라가세요.

| 파일 | 무엇인가 |
|------|----------|
| `과업지시서_데이터뱅크.hwpx` | 입력. 나라장터 공개 과업지시서 (병원 진료기록 연계 ETL 구축) |
| `제안서A_단일패스.docx` | 트랙 A. 단일 프롬프트 한 번으로 쓴 제안서 (3쪽) |
| `제안서B_하네스.docx` | 트랙 B. 전문가 에이전트 5명이 나눠 쓰고 검증한 제안서 (8쪽) |
| `artifacts/요구사항_인벤토리.md` | 트랙 B의 중간 산출물. REQ 11 / DOM 13 / CON 7 / DEL 4 |
| `CLAUDE.md` | 하네스: 모든 에이전트가 지키는 규칙 |
| `.claude/agents/` | 하네스: 요구분석가·도메인 전문가·기술 설계·관리 담당·검증자 |
| `.claude/skills/` | 하네스: 요구 추출 방법, 의료 데이터 표준 사전, 제안서 작성 표준 |

트랙 B를 집에서 처음부터 다시 돌려 보려면 이 폴더에서 `claude`를 띄우고 아래를 입력합니다. 20~40분이 걸리고 사용량을 꽤 씁니다.

```
rfp-analyst → domain-expert → (solution-architect ∥ pm-expert) → 통합
→ compliance-reviewer 파이프라인으로 과업지시서_데이터뱅크.hwpx 에 대한 제안서를 작성하세요.
compliance-reviewer가 전건 통과를 승인할 때까지 수정 루프를 돌리세요.
```
