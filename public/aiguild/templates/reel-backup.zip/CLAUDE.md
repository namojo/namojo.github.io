# CLAUDE.md — 작품 소개 showreel 하네스

## 언제 이 하네스를 쓰는가
- 이 폴더에서 작품(도서·영화·행사·게임) 소개 릴을 만들거나 고치는 요청은 **`reel-studio` 스킬**로 처리한다.
  예: `/reel-studio brief.md`, "brief.md 로 릴 만들어줘", "릴 검수만 다시 해줘", "3번 장면만 고쳐줘".
- 사용자가 `/showreel`이라고 **명시한 경우에만** 전역 showreel 스킬(MP4 영상 제작)을 쓴다. 그때도 이 폴더의
  `_workspace/01_research.md`와 `out/storyboard.md`를 입력으로 넘길 수 있다.

## 공통 규칙 (모든 에이전트)
- 화면에 나오는 사실(날짜·이름·수치·장소)은 `_workspace/01_research.md`에 ID와 출처가 있는 것만 쓴다.
- 줄거리의 반전·결말은 쓰지 않는다.
- 포스터·스틸·표지·로고·게임 화면 같은 저작물 이미지는 쓰지 않는다. 타이포그래피와 도형으로 만든다.
- 만든 담당은 자기 결과를 승인하지 않는다. 승인은 `reel-reviewer`만 한다.

## 파일 위치
- 입력: `brief.md` (없으면 `brief.example.md`를 복사해 채우게 안내한다)
- 중간 산출물: `_workspace/`
- 최종 산출물: `out/storyboard.md`, `out/reel.html`

## 변경 이력
| 날짜 | 변경 | 사유 |
|------|------|------|
| 2026-10-21 | 초기 구성 (에이전트 4 + 스킬 2) | AI Agent Guild 10월 세미나 백업 하네스 |
