---
name: reel-studio
description: "brief.md 를 읽어 작품(도서·영화·행사·게임) 소개 HTML 모션 릴을 조사 → 기획 → 제작 → 검수 순서로 만드는 오케스트레이터. '/reel-studio', 'brief.md 로 릴 만들어줘', '릴 다시 만들어줘', '검수만 다시', 'N번 장면 고쳐줘', '조사 보강해줘' 같은 요청에 사용한다. MP4 영상 렌더는 범위가 아니다 — 사용자가 /showreel 을 명시하면 그 스킬이 맡는다."
---

# reel-studio — 작품 소개 릴 오케스트레이터

누가, 언제, 어떤 순서로 일하는지를 정한다. 오케스트레이터는 직접 조사하거나 장면을 만들지 않는다. 각 단계는 Agent 도구로 해당 에이전트를 부른다.

## 팀 구조

```
[reel-researcher] → [reel-storyteller] → [reel-builder] ⇄ [reel-reviewer]
     조사                 기획·원고            제작            검수 (최대 2회 왕복)
```

- 패턴: **파이프라인**(앞 단계 파일이 있어야 다음 단계가 된다) + 마지막 구간 **생성·검증**.
- 실행 모드: 서브에이전트 위임을 순서대로. 단계 사이 데이터는 모두 파일로 넘긴다(`_workspace/`, `out/`).

## Phase 0 — 시작 점검
1. `brief.md`가 있는지 본다. 없으면 `brief.example.md`를 복사해 채우라고 안내하고 멈춘다.
2. 기존 산출물을 본다.
   - 아무것도 없으면 → Phase 1부터.
   - 사용자가 일부만 요청하면 해당 Phase부터: "조사 보강" → 1, "콘셉트/장면 바꿔" → 2, "N번 장면 고쳐" → 3, "검수만" → 4.
   - brief가 바뀌었으면 → Phase 1부터 다시. 이전 파일은 `_workspace/prev/`로 옮겨 둔다.
3. 사용자에게 한 줄로 알린다: "조사 → 기획 → 제작 → 검수 순서로 진행합니다."

## Phase 1 — 조사
- `reel-researcher` 호출. 입력 `brief.md`. 출력 `_workspace/01_research.md`.
- 관문: "brief 꼭 넣을 정보 대조" 표가 있고 모든 항목에 상태가 적혀 있어야 다음으로 간다. 없으면 한 번 다시 부른다.

## Phase 2 — 기획
- `reel-storyteller` 호출. 출력 `_workspace/02_concept.md`, `out/storyboard.md`.
- 관문: 후보 3개와 점수표가 있는가, 장면표의 마지막 끝 시각이 brief 길이와 같은가.

## Phase 3 — 제작
- `reel-builder` 호출. 출력 `out/reel.html`, `_workspace/03_build-notes.md`.

## Phase 4 — 검수와 수정
- `reel-reviewer` 호출. 출력 `_workspace/04_review.md`.
- 결론이 "수정 필요"면 지적의 **담당자에게만** 다시 맡긴다(사실 → researcher, 구성·문구 → storyteller, 코드 → builder).
  storyteller가 장면표를 고쳤으면 builder도 해당 장면을 다시 만든다. 그다음 reviewer를 다시 부른다.
- 왕복은 **최대 2회**. 2회 뒤에도 남은 지적은 고치지 말고 최종 보고에 "남은 문제"로 적는다. 끝없이 고치는 것보다 사람에게 넘기는 것이 낫다.

## Phase 5 — 보고
사용자에게 아래만 짧게 보고한다.
- 만든 파일 5개의 경로
- 검수 결론과 회차, 남은 문제
- 열어 보는 법: macOS `open out/reel.html`, Windows `start out\reel.html`
- 특정 순간 보기: 주소 끝에 `?t=5` (5초 지점에서 멈춤)

## 산출물 목록
| 파일 | 만든 담당 |
|------|-----------|
| `_workspace/01_research.md` | reel-researcher |
| `_workspace/02_concept.md` | reel-storyteller |
| `out/storyboard.md` | reel-storyteller |
| `out/reel.html` | reel-builder |
| `_workspace/03_build-notes.md` | reel-builder |
| `_workspace/04_review.md` | reel-reviewer |
