---
name: reel-html
description: "장면표(storyboard.md)를 브라우저에서 재생되는 단일 HTML 모션 릴로 옮기는 방법과 템플릿. reel-builder 가 out/reel.html 을 만들거나 고칠 때 Skill 도구로 불러 쓴다. 장면 구조, 움직임 효과 이름, 타이포그래피 규칙, 확인 방법이 들어 있다."
---

# reel-html — HTML 모션 릴 만드는 법

## 1. 시작
`assets/reel-template.html`을 `out/reel.html`로 복사한다. 템플릿에는 재생 엔진(시계·장면 전환·되감기·`?t=` 탐색)이 이미 들어 있다.
**엔진 `<script>`는 고치지 않는다.** 바꾸는 곳은 세 군데뿐이다.

1. `<title>`과 `:root`의 색 변수 (`--bg`, `--fg`, `--accent`, `--muted`)
2. `#stage` 안의 `<section class="scene">` 목록
3. 필요하면 `<style>` 맨 아래 `/* 장면별 스타일 */` 영역

## 2. 장면 하나의 구조

```html
<section class="scene" data-start="2.5" data-end="5.0">
  <h2 class="t-xl" data-a="rise" data-at="0.1">문구</h2>
  <p class="t-m" data-a="fade" data-at="0.6" data-fact="R3">2026년 10월 29일(목)</p>
  <div class="shape bar" data-a="wipe" data-at="0" data-loop="drift"></div>
</section>
```

- `data-start` / `data-end`: 장면표의 시작·끝 초를 그대로.
- `data-a`: 등장 효과. `data-at`: 장면 시작 기준 몇 초 뒤에 시작할지. `data-dur`: 효과 길이(초, 기본 0.8).
- `data-loop`: 등장 뒤 계속 움직이는 효과. 화면이 멈춰 보이지 않게 장면마다 하나는 둔다.
- `data-fact`: 사실 ID. 날짜·이름·수치·장소가 들어간 요소에는 반드시 단다.
- 장면 사이 페이드(0.25초 들어옴, 0.35초 나감)는 엔진이 처리한다.

## 3. 효과 이름
| `data-a` | 움직임 |
|----------|--------|
| `fade` | 서서히 나타남 |
| `rise` | 아래에서 떠오름 |
| `drop` | 위에서 내려옴 |
| `slide-l` / `slide-r` | 왼쪽·오른쪽에서 밀려옴 |
| `zoom` | 작게 시작해 제자리로 |
| `wipe` | 왼쪽부터 드러남 (막대·밑줄에 좋다) |
| `blur` | 흐렸다가 또렷해짐 |
| `type` | 글자가 한 자씩 찍힘 (글자 수만큼 `--n` 지정: `style="--n:8"`). 폭을 n등분해 드러내므로 중간 프레임에서 글자가 반쯤 잘려 보일 수 있다. 짧은 한 줄에 쓴다 |
| `spread` | 자간이 넓게 시작해 좁혀짐 |

| `data-loop` | 계속 움직임 |
|-------------|-------------|
| `drift` | 천천히 떠다님 |
| `pulse` | 크기가 아주 조금 숨쉬듯 |
| `spin` | 천천히 회전 (도형) |
| `scan` | 좌우로 훑음 (얇은 선) |

## 4. 글자와 도형
- 무대는 1920×1080 고정이고 창 크기에 맞춰 엔진이 축소한다. 글자 크기는 px로 쓴다.
- 클래스: `t-xxl`(220px) · `t-xl`(140px) · `t-l`(92px) · `t-m`(56px) · `t-s`(36px). 본문 글자는 36px보다 작게 쓰지 않는다.
- `wipe`·`type`은 요소 상자 폭을 기준으로 드러난다. `.col` 안의 짧은 줄처럼 상자가 글자보다 넓으면 빈 곳부터 드러나 어긋나므로 `.fit`을 함께 단다.
- 배치: `.center`(가운데), `.lt` `.rt` `.lb` `.rb`(네 귀퉁이 여백 120px), `.row`·`.col`(정렬 묶음).
- 도형: `.shape` + `.bar`(가로 막대) `.dot`(원) `.ring`(테두리 원) `.frame`(사각 테두리) `.grid`(격자 배경). 크기와 위치는 인라인 style로.
- 한 장면에 가장 큰 글자 하나, 나머지는 그보다 확실히 작게. 크기가 비슷한 글자 두 개가 경쟁하면 둘 다 안 읽힌다.
- 이미지 파일과 `url()` 배경은 쓰지 않는다. 질감은 그라데이션·격자·도형으로 만든다.

## 5. 확인
- 브라우저로 연다: macOS `open out/reel.html`, Windows `start out\reel.html`.
- `R` 처음부터, `Space` 일시정지, `←` `→` 1초 이동.
- `?t=7.5`를 붙이면 그 시점에서 멈춘 화면이 나온다. 장면마다 한 번씩 확인한다.
- `?clean=1`을 붙이면 아래 진행 막대와 안내 글자가 사라진다(녹화용).
